just drag the sdf onto convertSDF batch file, you turkey.

you may need to change the password in the batch file.. idk